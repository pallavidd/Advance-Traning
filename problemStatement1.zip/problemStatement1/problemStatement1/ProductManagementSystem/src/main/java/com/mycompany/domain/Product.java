package com.mycompany.domain;

public class Product {
int productId;
String ProductName;
int productPrice;
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public String getProductName() {
	return ProductName;
}
public void setProductName(String productName) {
	ProductName = productName;
}
public int getProductPrice() {
	return productPrice;
}
public void setProductPrice(int productPrice) {
	this.productPrice = productPrice;
}
@Override
public String toString() {
	return "Product [productId=" + productId + ", ProductName=" + ProductName + ", productPrice=" + productPrice + "]";
}
public Product(int productId, String productName, int productPrice) {
	super();
	this.productId = productId;
	ProductName = productName;
	this.productPrice = productPrice;
}
public Product() {
	super();
	// TODO Auto-generated constructor stub
}

}
