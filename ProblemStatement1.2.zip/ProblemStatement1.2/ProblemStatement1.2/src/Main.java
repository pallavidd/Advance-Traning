
public class Main {
	
	public static void main(String args[]) {
		
        RectangleProgram obj1 = new RectangleProgram();
        obj1.inputFromUser();
        obj1.calculate();
        obj1.display();
        System.out.println("--------------------------------");
        RectangleProgram obj2 = new RectangleProgram();
        obj2.inputFromUser();
        obj2.calculate();
        obj2.display();
        System.out.println("--------------------------------");
        RectangleProgram obj3 = new RectangleProgram();
        obj3.inputFromUser();
        obj3.calculate();
        obj3.display();
        System.out.println("-------------------------------");
        RectangleProgram obj4 = new RectangleProgram();
        obj4.inputFromUser();
        obj4.calculate();
        obj4.display();
        System.out.println("  ");
        System.out.println("-------------------------------");
        RectangleProgram obj5 = new RectangleProgram();
        obj5.inputFromUser();
        obj5.calculate();
        obj5.display();
    }
}
