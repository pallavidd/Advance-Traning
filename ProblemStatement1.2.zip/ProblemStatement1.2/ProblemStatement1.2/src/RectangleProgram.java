import java.util.Scanner;

public class RectangleProgram {
	 double length; 
	    double breadth; 
	    double area; 
	   
	    public RectangleProgram()
	    {
	    	length = 0;
	    	breadth= 0;
	    }

	    void inputFromUser() {
	        Scanner s1 = new Scanner(System.in);
	        System.out.print("Enter length of rectangle: ");
	        length = s1.nextDouble();
	        System.out.print("Enter breadth of rectangle: ");
	        breadth = s1.nextInt();
	    }

	    void calculate() {
	    	
	        area = length * breadth;
	        
	    }

	    void display() {
	    	
	        System.out.println("Area of Rectangle is = " + area);
	       
	    }

	    
}
