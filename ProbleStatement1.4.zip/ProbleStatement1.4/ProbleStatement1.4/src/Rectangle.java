import java.util.Scanner;

public class Rectangle {
	double length; 
	    double width; 
	    double area; 
	    double perimeter;
	    
	    public double getLength() {
			return length;
		}

		public void setLength(double length) {
			this.length = length;
		}

		public double getWidth() {
			return width;
		}

		public void setWidth(double width) {
			this.width = width;
		}

		
	    public Rectangle()
	    {
	    	length = 1;
	    	width= 1;
	    }

	    void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter length of rectangle: ");
	        length = in.nextDouble();
	        System.out.print("Enter width of rectangle: ");
	        width = in.nextDouble();
	    }
	    
	    void  areaRectangle()
	    {
	        area = length * width;
	       
	    }
	 
	     void  perimeterRectangle()
	    {
	    	 perimeter = 2*(length + width);
	       
	    }

	    void display() {
	    	
	    	if(length>0.0 && length<20.0 && width>0.0 && width<20.0)
	        {
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Perimeter of Rectangle = " +perimeter);
	       
	        }
	    
	    
	    else {
	        	System.out.println("Please Enter Length less than 20.0");

	        	
	        }

}
}
