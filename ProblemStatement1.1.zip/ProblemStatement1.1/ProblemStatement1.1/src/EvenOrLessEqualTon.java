import java.util.Scanner;

public class EvenOrLessEqualTon {

	public static void main(String[] args) {
		int i=1;
Scanner sc = new Scanner(System.in);
System.out.println("Enter the Number:-  ");
int num=sc.nextInt();
while(i<=num) {
	if(i%2==0) {
		System.out.println(i);
	}
	
	i++;
}
System.out.println("Theses are the Even numbers less than or equal to the given num ");


	}

}
